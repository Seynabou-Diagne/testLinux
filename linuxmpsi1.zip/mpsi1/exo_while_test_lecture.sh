#!/bin/bash
nbm=0
while [ $nbm -ne 5 ]; do
	read -p "Entrer le nombre magique pour sortir: " nbm
done
