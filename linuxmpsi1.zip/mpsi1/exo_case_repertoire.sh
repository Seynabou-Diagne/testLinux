#!/bin/bash
echo "Le contenu du répertoire courant va etre affiché."
read -p "Souhaitez-vous aussi afficher les fichiers cachés (oui/non): " choix
case $choix in
	oui)ls -a;;
	non)ls ;;
	*) echo "Veuillez répondre par oui ou par non.";;
esac

