#!/bin/bash
wget -qN 'http://www.spamhaus.org/drop/drop.txt'
for line in $( cat drop.txt | grep -i SBL | cut -f 1 -d ';')
	do
		if [[ $line=~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/[0-9]{1,2}$ ]]; then
			iptables -A INPUT -s $line -j DROP
		fi
done
