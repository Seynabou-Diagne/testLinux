#!/bin/bash
choix1=`ip -br a`
choix2=`free`
choix3=`df --output=pcent /`
PS3="Vous-voulez afficher..."
select val in "Ip" "RAM" "Partition" "Quitter"; do
	case $val in
		Ip) echo "L'adresse ip de la machine est : $choix1";;
		RAM) echo "L'utilisation de la RAM est : $choix2";;
		Partition) echo "La partition de la racine est de : $choix3";;
		Quitter) exit;;
		*) echo "Choix indisponible ";;
	esac
done




