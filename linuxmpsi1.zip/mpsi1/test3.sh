#!/bin/bash
#first parametre
var=$1

function stop () {
	if test -e /temp/script.pid; then
		rm /tmp/script.pid
		echo "Le fichier est supprimé"
	else
		echo "Le fichier n'existe pas"
	fi	
}

function start () {
	touch /tmp/script.pid
	echo "Le fichier est crée"
}

#if [ $1 == "start" ]; then
	#touch /tmp/script.pid
#	start
#elif [ $1 =="stop" ]; then
	#rm /temp/script.pid
#	stop
#elif [ $1 =="restart" ]; then
#stop
	#rm /tmp/script.pid -a 
	#touch /tmp/script.pid
#	start
#else
#	echo --help
#fi

case $var in
	 start | demarrer)	start;;

         stop  | arreter)  	stop;;
         restart)	stop; start;;
     	*) echo "Usage: $0 {start|stop|restart}";;
esac	

