#!/bin/bash
file='/etc/issue'
while read line; do
	echo $line
done <$file
