#!/bin/bash

read -p "Entrer votre nom : " nom
read -p "Entrer votre prenom : " prenom
echo "Bonjour  $prenom $nom  nous sommes le" $(date +%A\ %d\ %B\ %Y) 
#echo $(date +%d\ %B\ %Y)

