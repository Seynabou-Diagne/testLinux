#!/bin/bash
part=`df --output=pcent / | tail -1 | sed s/%//`

if [ $part -lt 50 ]; then
	echo "Vert"
elif [ $part -ge 50 ] && [ $part -le 75 ]; then
	echo "Orange"
elif [ $part -gt 75 ]; then
	echo "rouge"
fi

