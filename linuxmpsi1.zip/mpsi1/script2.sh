#!/bin/bash
#script2.sh
echo "Le nom de mon script est $0"
echo "Vous avez passé $# parametres; \$#"
echo "Voici la liste des parametres: $*; \$*"
echo "le premier parametre $1"
echo "le deuxieme parametre $2"
