#!/bin/bash
choix1=`uptime`
choix2=`free`
choix3=`df --output=pcent /`
PS3="Vous-voulez affichez..."
select val in "uptime" "free" "racine" "quitter"; do
	case $val in
		uptime) echo $choix1;;
		free) echo $choix2;;
		racine) echo $choix3;;
		quitter) exit;;
		*) echo "Choix incorrecte veuillez choisir : uptime | free | racine"
	esac
done
