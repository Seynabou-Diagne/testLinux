#!/bin/bash
PS3="Veuillez choisir l'operation -> "

select operation in "Retrait" "Versement" "Transfert"
do
	echo "Vous avez fait le choix numero $REPLY"
	echo "Vous allez faire une operation de type : $operation"
done
