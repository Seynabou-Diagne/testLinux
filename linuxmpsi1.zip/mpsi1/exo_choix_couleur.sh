#!/bin/bash

if [ $# -eq 0 ]; then
	read -p "Saisir une valeur entre 0 et 100 :" valeur
else 
	valeur=$1
fi

if [ $valeur -le 75 ]; then
	echo Vert

elif [ $valeur -gt 75 ] && [ $valeur -le 100 ]; then
	echo Rouge

elif [ $valeur -ne 0 ] && [ $valeur -ne 100 ]; then
	echo Erreur

else 
	echo "Choisir entre 0 et 100 "
fi
