#!/bin/bash

read -p "Entre une valeur : " val

if [ $val -lt 0 ]; then
	echo "La valeur saisie doit etre positif "
fi

for (( i=1;i<=$val;i++ )); do
	sum=`expr 1 + $i`
	moy=`expr $sum  / $val`
      	echo $moy	
done
echo $moy

	
