#!/bin/bash
case "$(groups)" in *\admin\*|*\sudo\*)
	if [ -x /usr/bin/sudo ]; then
		cat<<-EOF
		To run a commande as administrator (user "root"), use "sudo <commande>".
		See "man sudo_root" for details.
		EOF
	fi
esac
