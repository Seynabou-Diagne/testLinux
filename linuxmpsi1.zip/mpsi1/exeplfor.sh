#!/bin/bash
#table de multiplication

if [ $# -eq 0 ]; then
	read -p "Donner un argument : " var
else
	var=$1
fi
	for i in 1 2 3 4 5 6 7 8 9 ; do
		echo "$i * $var" = `expr $i \* $var`
	done
#fi

