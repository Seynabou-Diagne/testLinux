#!/bin/bash
#Authentification
read -p 'username:' username
read -s -p 'password:' password
if [ $username=="admin" -a $password=="secret" ]; then
	echo "login/mot de passe correct"
else
	echo "login/mot de passe incorrect"
fi
